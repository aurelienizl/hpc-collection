#ifndef GGML_SYCL_REPEAT_BACK_HPP
#define GGML_SYCL_REPEAT_BACK_HPP

#include "common.hpp"

void ggml_sycl_op_repeat_back(ggml_backend_sycl_context & ctx, ggml_tensor * dst);

#endif  // GGML_SYCL_REPEAT_BACK_HPP
